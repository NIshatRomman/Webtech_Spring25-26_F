const form = document.getElementById("contactForm");
const errorMessage = document.getElementById("errorMessage");
const successMessage = document.getElementById("successMessage");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const data = window.FormModel.getFormData();

  if (!window.FormModel.isFormValid(data)) {
    errorMessage.textContent = "Field Value need to be filled up";
    successMessage.textContent = "";
    return;
  }

  errorMessage.textContent = "";
  successMessage.textContent = "Form submitted successfully";

  console.log("First Name:", data.firstName);
  console.log("Last Name:", data.lastName);
  console.log("Email:", data.email);
  console.log("Phone Number:", data.phone);
  console.log("Message:", data.message);

  form.reset();
});