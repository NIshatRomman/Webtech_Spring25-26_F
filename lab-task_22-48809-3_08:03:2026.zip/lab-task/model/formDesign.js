const FormModel = {
  getFormData: function () {
    return {
      firstName: document.getElementById("firstName").value.trim(),
      lastName: document.getElementById("lastName").value.trim(),
      email: document.getElementById("email").value.trim(),
      phone: document.getElementById("phone").value.trim(),
      message: document.getElementById("message").value.trim()
    };
  },

  isFormValid: function (data) {
    return data.firstName !== "" &&
           data.lastName !== "" &&
           data.email !== "" &&
           data.phone !== "" &&
           data.message !== "";
  }
};

window.FormModel = FormModel;