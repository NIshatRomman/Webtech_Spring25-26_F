
<?php
// controllers/ActivityController.php
session_start();
include '../config/db.php';
include '../config/helpers.php'; // Member 3 er banano helper
include '../models/ActivityModel.php';
include '../models/TaskModel.php'; // Task er nam janar jonno

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["ok" => false, "message" => "Unauthorized"]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

// --- GET ACTIVITIES (AJAX Filter) ---
if ($method == 'GET' && isset($_GET['action']) && $_GET['action'] == 'fetch_activities') {
    $project_id = $_GET['project_id'];
    $user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';
    
    $activities = getProjectActivities($conn, $project_id, $user_id);
    
    // Format JSON with initials and time_ago
    $response_data = [];
    foreach($activities as $act) {
        $act['initials'] = strtoupper(substr($act['user_name'], 0, 2));
        $act['time_ago'] = time_ago($act['created_at']);
        $response_data[] = $act;
    }
    
    echo json_encode($response_data);
    exit();
}

// --- POST COMMENT (AJAX) ---
if ($method == 'POST' && isset($_POST['action']) && $_POST['action'] == 'post_comment') {
    $task_id = $_POST['task_id'];
    $body = trim($_POST['body']);
    $user_id = $_SESSION['user_id'];

    if (empty($body)) {
        echo json_encode(["ok" => false, "message" => "Comment cannot be empty"]);
        exit();
    }

    $comment_id = addComment($conn, $task_id, $user_id, $body);
    if ($comment_id) {
        $comment = getCommentById($conn, $comment_id);
        $task = getTaskById($conn, $task_id);
        
        // Log Activity: "Commented on task '[title]'"
        log_activity($conn, $task['project_id'], $user_id, "Commented on task '{$task['title']}'");
        
        echo json_encode(["ok" => true, "comment" => $comment]);
    } else {
        echo json_encode(["ok" => false, "message" => "Failed to post comment"]);
    }
    exit();
}

// --- DELETE COMMENT (AJAX DELETE Simulation via GET/POST parameter or pure DELETE) ---
// Note: Browser native form doesn't support DELETE, but AJAX can.
if ($method == 'DELETE' || (isset($_GET['action']) && $_GET['action'] == 'delete_comment')) {
    // Handling pure DELETE method parsing
    if ($method == 'DELETE') {
        parse_str(file_get_contents("php://input"), $_DELETE);
        $comment_id = $_DELETE['comment_id'];
    } else {
        $comment_id = $_GET['comment_id'];
    }
    
    $comment = getCommentById($conn, $comment_id);
    
    // Security verification: Only comment author can delete
    if ($comment && $comment['user_id'] == $_SESSION['user_id']) {
        $task = getTaskById($conn, $comment['task_id']);
        
        deleteComment($conn, $comment_id);
        
        // Log Activity requirement
        log_activity($conn, $task['project_id'], $_SESSION['user_id'], "Deleted a comment on task '{$task['title']}'");
        
        echo json_encode(["ok" => true]);
    } else {
        echo json_encode(["ok" => false, "message" => "Unauthorized to delete this comment"]);
    }
    exit();
}
?>