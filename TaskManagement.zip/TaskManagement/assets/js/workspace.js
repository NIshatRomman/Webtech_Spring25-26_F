
function removeWorkspaceMember(memberRowId) {
    if(confirm("Are you sure you want to remove this member?")) {
        // ১. AJAX অবজেক্ট তৈরি
        var xhttp = new XMLHttpRequest();
        
        // ২. স্টেট চেঞ্জ মনিটর করা
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                if(this.responseText.trim() === "success") {
                    // পেজ রিলোড ছাড়া জাভাস্ক্রিপ্ট দিয়ে টেবিল থেকে রো মুছে ফেলা
                    var row = document.getElementById("member-row-" + memberRowId);
                    if(row) {
                        row.parentNode.removeChild(row);
                    }
                } else {
                    alert("Failed to remove member!");
                }
            }
        };
        
        // ৩. কন্ট্রোলারে পোস্ট রিকোয়েস্ট পাঠানো
        xhttp.open("POST", "../controllers/WorkspaceController.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("action=remove_member&member_row_id=" + memberRowId);
    }
}