-- Database: task_management_db

-- ==============================================================
-- Member 1: User Auth & Workspace Management
-- ==============================================================

-- 1. Users Table (Authentication er jonno)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Workspaces Table (Workspace detail er jonno)
CREATE TABLE workspaces (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  owner_id INT NOT NULL,
  invite_code VARCHAR(10) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Workspace Members Table (Ke kon workspace e ache seta track korar jonno)
CREATE TABLE workspace_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  workspace_id INT NOT NULL,
  user_id INT NOT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ==============================================================
-- Member 2: Project Management
-- ==============================================================

-- 4. Projects Table (Project details, deadline, color code er jonno)
CREATE TABLE projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  workspace_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  deadline DATE,
  color_label VARCHAR(7) NOT NULL,
  is_archived TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Project Members Table (Kono specific project e kon kon member assigned ache)
CREATE TABLE project_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  user_id INT NOT NULL
);


-- ==============================================================
-- Member 3: Task Board & Status Management
-- ==============================================================

-- 6. Tasks Table (Kanban board er task, priority, due date, status er jonno)
CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  assigned_to INT NOT NULL,
  priority ENUM('low', 'medium', 'high') NOT NULL,
  due_date DATE,
  status ENUM('todo', 'in-progress', 'done') DEFAULT 'todo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Activity Logs Table (Ke ki action nilo seta save rakhar jonno)
-- N.B: Eta Member 4 filter korbe kintu table create ar task move er log Member 3 kora shuru korbe.
CREATE TABLE activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  project_id INT NOT NULL,
  user_id INT NOT NULL,
  action_text VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ==============================================================
-- Member 4: Comments & Activity Log
-- ==============================================================

-- 8. Comments Table (Task er bhitore ke ki comment korlo seta save korar jonno)
CREATE TABLE comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  task_id INT NOT NULL,
  user_id INT NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);