
<?php
// নতুন ইউজার তৈরি করা
function registerUser($conn, $name, $email, $password) {
    // পাসওয়ার্ড সিকিউর করার জন্য হ্যাশ করা
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $sql = "INSERT INTO users (name, email, password_hash) VALUES ('$name', '$email', '$hashed_password')";
    return mysqli_query($conn, $sql);
}

// ইমেইল দিয়ে ইউজার চেক করা (লগইনের জন্য)
function loginUser($conn, $email, $password) {
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        // ডাটাবেজের হ্যাশ পাসওয়ার্ডের সাথে ইনপুট পাসওয়ার্ড মেলানো
        if (password_verify($password, $user['password_hash'])) {
            return $user; // লগইন সফল হলে ইউজারের ডাটা রিটার্ন করবে
        }
    }
    return false; // ব্যর্থ হলে false
}

// ইমেইল আগে থেকে আছে কিনা চেক করা
function checkEmailExists($conn, $email) {
    $sql = "SELECT id FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) > 0;
}
?>